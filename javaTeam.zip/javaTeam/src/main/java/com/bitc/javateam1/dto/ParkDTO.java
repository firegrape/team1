package com.bitc.javateam1.dto;

import lombok.Data;

@Data
public class ParkDTO {

private int seq;
private String local;
private String name;
private String location;

private String keyword;
private String type;
}
