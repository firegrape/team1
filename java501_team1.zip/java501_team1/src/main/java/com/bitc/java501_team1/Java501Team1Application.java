package com.bitc.java501_team1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Java501Team1Application {

	public static void main(String[] args) {
		SpringApplication.run(Java501Team1Application.class, args);
	}

}
