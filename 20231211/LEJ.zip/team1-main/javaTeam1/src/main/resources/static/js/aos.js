AOS.init({
  duration: 1100 //aos 나타나는 속도
})