package com.bitc.javateam1.service;

import com.bitc.javateam1.dto.ParkDTO;

public interface ParkService {
   public ParkDTO selectParkList()throws Exception;
}
