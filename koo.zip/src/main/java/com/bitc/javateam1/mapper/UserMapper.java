package com.bitc.javateam1.mapper;

import com.bitc.javateam1.dto.UserDTO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface UserMapper {
    int isUserInfo(@Param("id") String id,@Param("password") String password) throws Exception;

    UserDTO getUserInfo(@Param("id") String id) throws Exception;
}
