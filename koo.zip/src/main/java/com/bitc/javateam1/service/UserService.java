package com.bitc.javateam1.service;

import com.bitc.javateam1.dto.UserDTO;

public interface UserService {
    int isUserInfo(String id, String password) throws Exception;

    UserDTO getUserInfo(String id) throws Exception;
}

