package com.bitc.javateam1.dto;

import lombok.Data;

@Data
public class UserDTO {
    private int idx;
    private String id;
    private String password;
    private String nickname;
    private String name;
    private String regidate;
    private int Grade;

}
