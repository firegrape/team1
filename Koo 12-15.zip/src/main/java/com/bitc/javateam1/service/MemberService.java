package com.bitc.javateam1.service;

import com.bitc.javateam1.dto.BoardDTO;
import com.bitc.javateam1.dto.MemberDTO;
import com.github.pagehelper.Page;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface MemberService {


 public void register(MemberDTO memberDTO) throws Exception;

 public int isUserInfo(String id, String password) throws Exception;

public MemberDTO getUserInfo(String id) throws Exception;

 Page<MemberDTO> userList(int pageNum) throws Exception;

 MemberDTO userDetail(int idx);

 void deleteUser(String id);

}
