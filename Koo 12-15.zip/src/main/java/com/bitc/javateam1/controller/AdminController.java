package com.bitc.javateam1.controller;

import com.bitc.javateam1.dto.BoardDTO;
import com.bitc.javateam1.dto.MemberDTO;
import com.bitc.javateam1.service.BoardService;
import com.bitc.javateam1.service.MemberService;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/")
public class AdminController {

    @Autowired
    private MemberService memberService;
    @Autowired
    private BoardService boardService;
    //회원 목록
    @GetMapping("admin")
    public ModelAndView userList(@RequestParam(required = false, defaultValue = "1", value = "pageNum") int pageNum) throws Exception {
        ModelAndView mv = new ModelAndView("board/adminboard/userList");

        PageInfo<MemberDTO> PageList = new PageInfo<>(memberService.userList(pageNum), 5);
        mv.addObject("PageList", PageList);

        return mv;
    }

    //회원 상세
    @GetMapping("admin/{idx}")
    public ModelAndView userDetail(@PathVariable("idx") int idx) throws Exception {
        ModelAndView mv = new ModelAndView("board/adminboard/userManage");

        MemberDTO user = memberService.userDetail(idx);
        mv.addObject("user", user);

        return mv;
    }

    //회원 탈퇴
    @RequestMapping("admin/deleteUser.do")
    public String deleteUser(@RequestParam("id") String id) throws Exception {
        memberService.deleteUser(id);

        return "redirect:/admin";
    }

    @PostMapping("admin/userPost")
    public ModelAndView postList(@RequestParam(required = false, defaultValue = "1", value = "pageNum") int pageNum, @RequestParam("cmId")String cmId) throws Exception {
        ModelAndView mv = new ModelAndView("board/adminboard/userPost");

        PageInfo<BoardDTO> PageList = new PageInfo<>(boardService.postList(pageNum, cmId), 5);
        mv.addObject("PageList", PageList);


        return mv;
    }
}
